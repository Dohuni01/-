// src/pages/Pay.jsx
import React, { useState } from "react";
import SwipePage from "../components/SwipePage";

const ACCOUNTS = [
  { bank: "카카오뱅크", barcode: "/barcode1.png", qr: "/qr1.png" },
  { bank: "국민은행", barcode: "/barcode2.png", qr: "/qr2.png" },
  { bank: "토스뱅크", barcode: "/barcode3.png", qr: "/qr3.png" },
];

export default function Pay() {
  const [idx, setIdx] = useState(0);

  // 상/하 스와이프
  const { ref } = require("react-swipeable")({
    onSwipedUp: () => setIdx((i) => (i < ACCOUNTS.length - 1 ? i + 1 : i)),
    onSwipedDown: () => setIdx((i) => (i > 0 ? i - 1 : i)),
    delta: 30,
    preventDefaultTouchmoveEvent: true,
    trackTouch: true,
    trackMouse: false,
  });

  const acc = ACCOUNTS[idx];

  return (
    <SwipePage>
      <div ref={ref} className="flex flex-col items-center justify-center min-h-screen bg-[#f7f8fa] px-4">
        <div className="text-3xl font-bold mb-6">{acc.bank}</div>
        <div className="flex flex-col gap-8 items-center">
          <img src={acc.barcode} alt="바코드" className="w-64 h-20 object-contain bg-gray-100 rounded" />
          <img src={acc.qr} alt="QR코드" className="w-40 h-40 object-contain bg-gray-100 rounded" />
        </div>
        <div className="text-sm text-gray-400 mt-4">{idx + 1} / {ACCOUNTS.length}</div>
      </div>
    </SwipePage>
  );
}
