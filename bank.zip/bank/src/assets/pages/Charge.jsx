// src/pages/Charge.jsx
import React, { useState } from "react";
import SwipePage from "../components/SwipePage";

const ACCOUNTS = [
  { name: "카카오뱅크", num: "3333-12-4567890", amount: "1,200,000원" },
  { name: "국민은행", num: "093-12-000234", amount: "340,000원" },
  { name: "토스뱅크", num: "1002-456-777777", amount: "20,000원" },
];

export default function Charge() {
  const [zoomIdx, setZoomIdx] = useState(null);

  return (
    <SwipePage>
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#f7f8fa] px-3">
        <div className="w-full max-w-sm flex flex-col gap-6 py-10">
          {ACCOUNTS.map((acc, i) => (
            <button
              key={acc.num}
              className={`w-full h-24 rounded-2xl bg-white shadow-md flex flex-col justify-center items-center border-2 transition 
                ${zoomIdx === i ? "scale-110 border-yellow-400 z-10" : "border-transparent"}`}
              style={{ transition: "transform 0.2s, border-color 0.2s" }}
              onPointerDown={() => {
                setZoomIdx(i);
              }}
              onPointerUp={() => setZoomIdx(null)}
              onPointerLeave={() => setZoomIdx(null)}
            >
              <div className="text-lg font-bold">{acc.name}</div>
              <div className="text-sm text-gray-500">{acc.num}</div>
              <div className="text-xl text-blue-500 font-bold mt-2">{acc.amount}</div>
            </button>
          ))}
        </div>
      </div>
    </SwipePage>
  );
}
