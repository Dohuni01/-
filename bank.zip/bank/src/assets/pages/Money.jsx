// src/pages/Money.jsx
import React from "react";
import SwipePage from "../components/SwipePage";
export default function Money() {
  return (
    <SwipePage>
      <div className="flex flex-col justify-center items-center min-h-screen bg-[#f7f8fa]">
        <div className="text-2xl font-bold text-gray-400">빈 페이지</div>
      </div>
    </SwipePage>
  );
}
